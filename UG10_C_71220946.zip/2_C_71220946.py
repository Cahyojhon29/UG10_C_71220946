bulan = int(input("Masukkan bulan (1-12) : "))
if (bulan == 2):
    hari = 28
    print ("Jumlah hari : 28")
elif "1" or "3" or "5" or "7" or "8" or "9" or "11" in bulan :
    print ("Jumlah hari : 31")
elif "4" or "6" or "10" or "12" in bulan :
    print ("Jumlah hari : 30")
