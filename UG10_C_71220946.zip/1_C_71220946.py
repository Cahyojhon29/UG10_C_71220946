print("========== Pilih menu ==========")
print("1. Tambah")
print("2. Kurang")
print("3. Kali")
print("4. Bagi")


angka1= int(input("Masukkan angka pertama : "))
angka2= int(input("Masukkan angka kedua : "))

pil = int(input("Pilihan Anda : "))

if pil == 1:
   hasil = angka1+angka2
elif pil == 2:
   hasil = angka1-angka2
elif pil == 3:
   hasil = angka1*angka2
elif pil == 4:
   hasil = angka1/angka2

print("\nHasil : %d" %hasil)
